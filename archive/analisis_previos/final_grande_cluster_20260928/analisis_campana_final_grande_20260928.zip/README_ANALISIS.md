# Análisis — campaña final grande 2026-09-28

## Integridad
- 43 archivos del manifiesto SHA256 verificados; discrepancias: 0.
- 6 observaciones útiles por método y tamaño.
- Todos los MPI: valid=1.
- Máximo residuo proyectado: 3.24029049237e-15.
- Máxima diferencia de factor LAPACK vs referencia: 8.86621841495e-15.

## Resultado principal (`factor_s`)
### N=6144
- C propio: 27.269004 s
- MPI P=6: 16.298454 s
- LAPACK/OpenBLAS 1 hilo: 1.899152 s
- Speedup MPI vs C propio: 1.673x
- Eficiencia MPI respecto de P=6: 27.9%
- Speedup LAPACK vs C propio: 14.359x
- MPI tarda 8.582x el tiempo de LAPACK.

### N=8192
- C propio: 72.091515 s
- MPI P=6: 36.953931 s
- LAPACK/OpenBLAS 1 hilo: 5.915935 s
- Speedup MPI vs C propio: 1.951x
- Eficiencia MPI respecto de P=6: 32.5%
- Speedup LAPACK vs C propio: 12.186x
- MPI tarda 6.247x el tiempo de LAPACK.

## Lectura prudente
En ambos tamaños MPI mejora al C propio, pero LAPACK/OpenBLAS de un hilo permanece claramente por delante.
Entre los dos tamaños ensayados en esta misma sesión, la relación MPI/LAPACK baja de
8.58x a 6.25x; esto muestra un acercamiento
entre esos dos puntos, no demuestra un cruce futuro ni una tendencia monotónica.

`factor_s` debe mantenerse como métrica principal para esta pregunta. La generación secuencial presenta un
salto muy grande en N=8192 (mediana ~3.98 s frente a ~0.402 s en N=6144), por lo que no conviene usar
`total_s` para inferir escalado entre tamaños sin estudiar aparte ese efecto.

Una hipótesis plausible para ese salto es la interacción del patrón de escritura simétrica de `generate_spd`
con el stride exacto de 65536 bytes en N=8192 (8192 doubles por fila), pero la campaña no prueba causalidad.
No es necesario resolverlo para la comparación de factorización porque la generación queda fuera de `factor_s`.

## Cgroup
- nr_throttled: +1676
- throttled_usec: +4376492 us

Hubo throttling observable durante la campaña. Se registra como condición del entorno; el agregado de `cpu.stat`
no permite atribuirlo a una repetición concreta.

## Conclusión experimental
Hasta N=8192, con la asignación de 6 CPUs, no se observó un cruce entre MPI P=6 y LAPACK/OpenBLAS de un hilo.
MPI reduce el tiempo del kernel propio, pero no compensa la ventaja del kernel local optimizado de LAPACK.
